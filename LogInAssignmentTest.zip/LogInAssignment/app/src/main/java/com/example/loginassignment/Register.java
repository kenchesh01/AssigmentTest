package com.example.loginassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    EditText mail,Password,name;
    Button register;
    TextView login;
    SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        // UI Elements
        name = findViewById(R.id.name);
        mail = findViewById(R.id.mail_id);
        Password = findViewById(R.id.passWord_id);
        login = findViewById(R.id.Login);
        register = findViewById(R.id.register);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences = getSharedPreferences("test",MODE_PRIVATE);
                String Mail_1 = mail.getText().toString();
                String password_1 = Password.getText().toString();
                String name_1 = name.getText().toString();
                   SharedPreferences.Editor editor = preferences.edit();
                   editor.putString(Mail_1+password_1+"data",Mail_1+ "\n"+password_1);
                   editor.putString("mail_1", Mail_1);
                   editor.putString("passwords", password_1);
                    editor.putString("Name", name_1);
                   editor.commit();
                   Toast.makeText(Register.this,"registered",Toast.LENGTH_LONG).show();

            }
        });
    }

    public void Login_user(View view) {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}