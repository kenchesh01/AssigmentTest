package com.example.loginassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class Profile extends AppCompatActivity {
TextView U_mail,U_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        U_mail = findViewById(R.id.email);
        U_password = findViewById(R.id.passWordUser);
        //
        SharedPreferences preferences = getSharedPreferences("test",MODE_PRIVATE);
        String Mail_1 = preferences.getString("mail_1","");
        String password_1 = preferences.getString("passwords","");
        U_mail.setText(Mail_1);
        U_password.setText(password_1);
    }
}