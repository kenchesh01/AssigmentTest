package com.example.loginassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
EditText mail,Password;
Button login;
TextView register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI Elements
        mail = findViewById(R.id.mail_id);
        Password = findViewById(R.id.passWord_id);
        login = findViewById(R.id.Login);
        register = findViewById(R.id.create);

        //login moving to dash board
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Mail = mail.getText().toString();
                String password = Password.getText().toString();
                SharedPreferences preferences = getSharedPreferences("test",MODE_PRIVATE);
                 String userdata = preferences.getString(Mail+password+"data","user_mail or pass word wrong ");
                SharedPreferences.Editor editor=preferences.edit();
                editor.putString("display",userdata);
                editor.commit();
                    Intent intent = new Intent(MainActivity.this,DashBoard.class);
                    startActivity(intent);
                }


        });



    }

    public void create_user(View view) {
        Intent intent = new Intent(this,Register.class);
        startActivity(intent);

    }
}