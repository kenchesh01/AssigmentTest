package com.example.loginassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class DashBoard extends AppCompatActivity {
TextView profile,upload,MyUpload,logOut,name;
SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);

        upload = findViewById(R.id.Audio);
        MyUpload =findViewById(R.id.upload);
        profile = findViewById(R.id.my_profile);
        logOut = findViewById(R.id.Logout);
        name = findViewById(R.id.name);
        SharedPreferences preferences = getSharedPreferences("test",MODE_PRIVATE);
        String Name_1 = preferences.getString("Name","");
        name.setText(Name_1);

    }

    public void logout(View view) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        finish();
    }



    public void my_uploads(View view) {

    }

    public void upload_audio(View view) {
        Intent intent = new Intent(DashBoard.this,UploadNew.class);
        startActivity(intent);
    }

    public void my_profile(View view) {
        Intent intent = new Intent(DashBoard.this,Profile.class);
        startActivity(intent);

    }
}